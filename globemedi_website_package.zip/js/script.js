
console.log('Globe Medi Travel JS loaded.');
